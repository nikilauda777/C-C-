#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "StrassenReader.c"




struct City {
    int id;
    char *name;
    int visited;
};



struct City getStadt(char line[]) {


    int stadtID;
    int einwohner;
    int gebietId;
    int meereshoehe;
    int whitespace = 0;
    int index = 0;


       char *name = (char *) malloc(sizeof(char) * 13);
    char element[13];


    for (int i = 0; i < strlen(line); i++) {

        if (line[i] == ' ' || (i + 1 == strlen(line))) {
            // add attributes

            if (whitespace == 0) {
                stadtID = atoi(element);

            } else if (whitespace == 1) {

                for (int j = 0; j < strlen(element); j++) {
                    name[j] = element[j];
                }
            }
            if (whitespace == 2) {

                einwohner = atoi(element);
            }
            if (whitespace == 3) {

                gebietId = atoi(element);
            }
            if (whitespace == 4) {
                meereshoehe = atoi(element);
            }

            whitespace++;
            index = 0;

            //remove the line
            for (int i = 0; i < 13; i++) {
                element[i] = NULL;
            }

            continue;

        }

        element[index++] = line[i];

    }

    struct City city = {stadtID, name, 0};
    return city;
}


void readfromStadt(struct City storage[], char *filename) {

    int newLine = 0;

    int c;
    FILE *file;
    file = fopen(filename, "r");

    if (file) {

        char line[35];
        int index = 0;

        while ((c = getc(file)) != EOF) {

            if (c == '\n' || c == '\0') {    // wenn die Zeile endet
                storage[newLine++] = getStadt(line); // create new Stadt and add to array

                for (int i = 0; i < 35; i++) { // clear var line   // delete from
                    line[i] = NULL;
                }

                index = 0; // index of line is zero
            }

            line[index++] = c;   // идет дальше , записывает по символьно

        }
        fclose(file);

    }

}

