#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "StadtReader.c"


/**
Structure City enthält eindeutige ID, Stadtbezeichnung und Eigenschaft visited
**/


// Liste der Städte, kann auch aus der stadt.dat Datei geladen werden
struct City city[38];



//Liste der Strassen {CityID1, CityID2}, kann auch aus der strasse.dat Datei geladen werden
//Stellt die Kanten eines ungerichteten Graphen dar.
int street[][2];


//Pointer auf erste besuchte Stadt
struct City *start;



// Befüllen mit den Städten aus der Liste
void fillCity(struct City storage[], struct Strasse storage1[]) {
    for (int i = 0; i < (sizeof city / sizeof city[0]); i++) {
         city[i] = storage[i];

    }

    for (int i = 0; i < 52; i++) {   // befüllen mit allen möglichen Wege auch hin und her
        street[i][0] = storage1[i].vonStadtID;
        street[i][1] = storage1[i].nachStadtID;
    }

//
//    printf("%d\n",street[51][0]);
//    printf("%d",street[51][1]);
}




//Pointer auf erste besuchte Stadt
struct City *start;

//Funktion liefert die Eigenschaft visited zurück. 0=nicht besucht, 1= besucht.
int visited(int cityId){
    int res = 0;
    for(int i = 0; i < (sizeof city / sizeof city[0]); i++){
        if(city[i].id == cityId){
            if(city[i].visited == 1) res = 1;
        }
    }
    return res;
}

/**
Funktion durchsucht alle Verbindungen zu und von der Stadt mit der id cityID.
Aus den möglichen Ziel-IDs wir ein Array gebildet und ein
zufälliges Element daraus zurückgeliefert.
**/
int randomCity(int cityID){

    int streets[10];
    int cnt = 0;
    int vis;


    for(int i = 0; i < 52; i++){

        //Verbindungen von der Stadt weg
        if (street[i][0] == cityID){
            vis = visited(street[i][1]);
            if(vis == 0 || start->id == street[i][1]){
                streets[cnt] = street[i][1];
                cnt++;
            }
        }

        //Verbindungen zu der Stadt hin
        if (street[i][1] == cityID){
            vis = visited(street[i][0]);
            if(vis == 0 || start->id == street[i][0]){
                streets[cnt] = street[i][0];
                cnt++;
            }
        }
    }

    if(cnt > 0){
        //Zufälliges Element zurückliefern
        return streets[rand() % cnt];
    }else{
        //Sackgasse, cnt = 0
        return cnt;
    }
}

/**
Liefert einen Pointer auf die Stadt mit der id cityID
**/
struct City *getCityById(cityId){
    for(int i = 0; i < (sizeof city / sizeof city[0]); i++){
        if(city[i].id == cityId){
            return &city[i];
        }
    }
    return &city[0];
}

/**
Rekursive Funktion
Liefert -1, falls wieder am Ausgangspunkt angelangt.
Liefert 0, wenn keine weiteren Verbindungen möflich (Sackgasse)
Ruft sich selbst auf, um weitere zufällige Städte zu besuchen.
**/

int go(struct City *city){

    //Wenn in der Start-Stadt angelangt, die schon besucht wurde.
    //Hier wird nicht unterschieden, ob man am Ausgangspunkt deshalb zurückkehrt, weil man aus einer Sackgasse zurückgekommen ist ud noch weitere Routen möglich wären.
    if(city->id == start->id && start->visited == 1){
        return -1;

    }else{
        printf("\nVisiting %s", city->name);
        //Stadt als besucht markieren´
        city->visited = 1;
        //rndCity enthält die ID einer zufälligen Stadt, die besucht werden kann, oder 0 in Sackgasse.
        int rndCity;
        //alle Nachbarstädte in zufälliger Reihenfolge besuchen, falls nicht zuerst die Rundreise am Ausgangspunkt endet.

        do{
            rndCity = randomCity(city->id);
            if (rndCity == 0) printf("\nSackgasse in %s", city->name);
            if (rndCity > 0) {
                struct City *nextCity = getCityById(rndCity);
                //Rekursiver Aufruf
                int next = go(nextCity);
                if(next == -1){
                    //Rundreise zu Ende
                    return next;
                }else{
                    printf("\nZurück in %s", city->name);
                    rndCity = randomCity(city->id);
                }
            }
        } while (rndCity > 0);
        return rndCity;
    }
}




//main method
int main(void){
    //init Randomizes
    //srand(time(NULL));
    /* Intializes random number generator */

    struct City cities[38];
    struct Strasse ListOfStrassen[52];

    readfromStadt(cities, "File/stadt.dat");
    readfromStrasse(ListOfStrassen, "File/strasse.dat");
    fillCity(cities,ListOfStrassen);

    time_t t;
    srand((unsigned) time(&t));
    start = &city[rand() % (sizeof city / sizeof city[0])]; // тут генерирует рандомный город    //----

    int roundTrip = go(start);

    if(roundTrip == -1)
        printf("\nReturned to %s", start->name);

    return 0;
}
