#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "GebietReader.c"


struct Strasse {
    int vonStadtID;
    int nachStadtID;
    int entfernung;
};



//strasse.dat   vonStadtId nachStadtId entfernung
struct Strasse getStrasse(char line[]) {


    int vonStadtId;
    int nachStadtId;
    int entfernung;

    int whitespace = 0;
    int index = 0;

    char element[13];

    for (int i = 0; i < strlen(line); i++) {

        if (line[i] == ' ' || (i + 1 == strlen(line))) {
            // add attributes
            if (whitespace == 0) {
                vonStadtId = atoi(element);
            }
            if (whitespace == 1) {
                nachStadtId = atoi(element);
            }
            if (whitespace == 2) {
                entfernung = atoi(element);
            }

            whitespace++;
            index = 0;

            //remove the line
            for (int i = 0; i < 13; i++) {
                element[i] = (char) NULL;
            }
            continue;
        }
        element[index++] = line[i];
    }
    struct Strasse street = {vonStadtId, nachStadtId, entfernung};
    return street;
}

struct Strasse getStrasse2(char line[]) {


    int vonStadtId;
    int nachStadtId;
    int entfernung;

    int whitespace = 0;
    int index = 0;

    char element[13];

    for (int i = 0; i < strlen(line); i++) {

        if (line[i] == ' ' || (i + 1 == strlen(line))) {
            // add attributes
            if (whitespace == 0) {
                nachStadtId= atoi(element);
            }
            if (whitespace == 1) {
                vonStadtId = atoi(element);
            }
            if (whitespace == 2) {
                entfernung = atoi(element);
            }

            whitespace++;
            index = 0;

            //remove the line
            for (int i = 0; i < 13; i++) {
                element[i] = NULL;
            }
            continue;
        }
        element[index++] = line[i];
    }
    struct Strasse street = {vonStadtId,nachStadtId, entfernung};
    return street;
}



/** reading of files+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++**/


void readfromStrasse(struct Strasse storage[], char *filename) {
    int newLine = 0;
    int c;
    FILE *file;
    file = fopen(filename, "r");

    if (file) {
        char line[35];
        int index = 0;

        while ((c = getc(file)) != EOF) {

            if (c == '\n' || c == '\0') {    // wenn die Zeile endet
                storage[newLine++] = getStrasse(line); // create new Stadt and add to array
                //storage[newLine++] = getStrasse2(line); // create new Stadt and add to array

                for (int i = 0; i < 35; i++) { // clear var line   // delete from
                    line[i] = NULL;
                }
                index = 0; // index of line is zero
            }
            line[index++] = c;   // идет дальше , записывает по символьно
        }
        fclose(file);
    }
}
