#include <stdio.h>
#include <string.h>
#include <stdlib.h>




struct Gebiet {
    int gebietID;
    char *name;
    int obergebietId;
    char *typ;
};


////gebiet.dat   gebietId name obergebietId typ

struct Gebiet getGebiet(char line[]) {

    int gebietId;
    int obergebietId;
    char typ;

    int whitespace = 0;
    int index = 0;

    char *name = (char *) malloc(sizeof(char) * 20);
    char element[20];


    for (int i = 0; i < strlen(line); i++) {

        if (line[i] == ' ' || (i + 1 == strlen(line))) {    // add attributes


            if (whitespace == 0) {
                gebietId = atoi(element);

            } else if (whitespace == 1) {

                for (int j = 0; j < strlen(element); j++) {
                    name[j] = element[j];
                }
            }
            if (whitespace == 2) {
                obergebietId = atoi(element);
            }

            if (whitespace == 3) {
                typ = atoi(element);
            }

            whitespace++;
            index = 0;

            //remove the line
            for (int i = 0; i < 20; i++) {
                element[i] = NULL;
            }
            continue;
        }

        element[index++] = line[i];
    }
    // printf("%d\n",gebietId);
    struct Gebiet region = {gebietId, name, obergebietId, typ};
    return region;
}



void readfromGebiet(struct Gebiet storage[], char *filename) {
    int newLine = 0;
    int c;
    FILE *file;
    file = fopen(filename, "r");

    if (file) {
        char line[35];
        int index = 0;

        while ((c = getc(file)) != EOF) {

            if (c == '\n' || c == '\0') {    // wenn die Zeile endet
                storage[newLine++] = getGebiet(line); // create new Stadt and add to array

                for (int i = 0; i < 35; i++) { // clear var line   // delete from
                    line[i] = NULL;
                }
                index = 0; // index of line is zero
            }
            line[index++] = c;   // идет дальше , записывает по символьно
        }
        fclose(file);
    }
}
